# Supplementary Material: Monotonicity Constraints for Adversarial Robustness

This repository contains the implementation code for experiments testing whether monotonic constraints on neural network feed-forward sublayers improve adversarial robustness in language models.

## Overview

This codebase implements a systematic experimental pipeline to:

1. Apply monotonic constraints (non-negative weights via softplus parametrization) to FFN sublayers
2. Train both baseline and monotonic-constrained models with identical hyperparameters
3. Evaluate models on standard language modeling benchmarks
4. Test adversarial robustness using Universal Adversarial Triggers (UAT) and HotFlip attacks

**Key Implementation Detail:** Only feed-forward network (FFN) sublayers are constrained to have non-negative weights. The full model is NOT globally monotonic, as attention mechanisms, layer normalization, and residual connections remain unconstrained.

## Directory Structure

```
supplementary_material/
├── configs/
│   └── experiment_config.py       # Experiment configuration
├── scripts/
│   ├── stage_0_setup.py            # Download model and prepare environment
│   ├── stage_1_apply_monotonicity.py  # Apply monotonic constraints
│   ├── stage_2_train_baseline.py   # Train unconstrained baseline
│   ├── stage_3_train_monotonic.py  # Train monotonic-constrained model
│   ├── stage_4_evaluate.py         # Evaluate on benchmarks
│   ├── stage_5_uat_attacks.py      # Universal Adversarial Trigger attacks
│   ├── stage_6_hotflip_attacks.py  # HotFlip attacks
│   └── stage_7_aggregate.py        # Aggregate and summarize results
├── utils/
│   └── common_utils.py             # Shared utilities
├── requirements.txt                # Python dependencies
└── README.md                       # This file
```

## Installation

### Prerequisites

- Python 3.10 or higher
- CUDA-capable GPU (recommended for training; CPU-only mode is extremely slow)
- ~80GB disk space for model weights and datasets
- ~40GB GPU memory (for Pythia-1.4B; smaller models available)

### Setup

1. Clone or extract this supplementary material:
```bash
cd supplementary_material/
```

2. Create a Python virtual environment:
```bash
python3 -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
```

3. Install PyTorch with CUDA support:
```bash
# For CUDA 11.8
pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu118

# Or for CUDA 12.1
pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu121

# Or for CPU-only (not recommended)
pip install torch torchvision torchaudio
```

4. Install other dependencies:
```bash
pip install -r requirements.txt
```

5. Verify installation:
```bash
python verify_installation.py
```

This will check that all dependencies are installed and the project structure is correct.

## Configuration

Edit `configs/experiment_config.py` to customize:

- **WORK_DIR**: Working directory for intermediate files (default: `./work`)
- **RESULTS_DIR**: Directory for results (default: `./results`)
- **MODEL_NAME**: Foundation model to use (default: `"EleutherAI/pythia-1.4b"`)
- **CURRENT_SEED**: Random seed for reproducibility (default: `42`)
- **BATCH_SIZE**: Training batch size (default: `8`)
- **USE_FULL_EVAL_SETS**: Use full evaluation sets vs. quick testing subsets

For quick testing on limited hardware, you can:
- Set `USE_FULL_EVAL_SETS = False` to use smaller evaluation sets
- Set `QUICK_TRAINING_SAMPLES = 10000` for faster training
- Use a smaller model by changing `MODEL_NAME` to `"EleutherAI/pythia-410m"`

## Usage

### Quick Start: Run All Stages

```bash
# Set working directory (or edit in config)
export WORK_DIR="./work"
export RESULTS_DIR="./results"

# Optional: Set random seed
export EXPERIMENT_SEED=42

# Run all stages sequentially
python scripts/stage_0_setup.py
python scripts/stage_1_apply_monotonicity.py
python scripts/stage_2_train_baseline.py
python scripts/stage_3_train_monotonic.py
python scripts/stage_4_evaluate.py
python scripts/stage_5_uat_attacks.py
python scripts/stage_6_hotflip_attacks.py
python scripts/stage_7_aggregate.py
```

### Stage-by-Stage Explanation

#### Stage 0: Setup
Downloads the foundation model and prepares the environment.
```bash
python scripts/stage_0_setup.py
```
- Downloads model weights (~5-10 minutes)
- Creates necessary directories
- Validates GPU availability
- Outputs: `setup_complete.json`, completion flag

#### Stage 1: Apply Monotonicity
Applies softplus parametrization to FFN layers.
```bash
python scripts/stage_1_apply_monotonicity.py
```
- Loads pretrained model
- Identifies FFN layers (e.g., `dense_h_to_4h`, `dense_4h_to_h` in Pythia)
- Applies parametrization: W = softplus(V) ≥ 0
- Saves monotonic-initialized model
- Outputs: `monotonic_initialized.pt`, statistics

#### Stage 2: Train Baseline
Trains unconstrained baseline model.
```bash
python scripts/stage_2_train_baseline.py
```
- Loads pretrained model (no constraints)
- Trains on language modeling data
- Uses identical hyperparameters as monotonic model
- Saves checkpoints and training history
- Outputs: `baseline_model.pt`, `baseline_training_history.json`

#### Stage 3: Train Monotonic
Trains monotonic-constrained model.
```bash
python scripts/stage_3_train_monotonic.py
```
- Loads monotonic-initialized model from Stage 1
- Trains with same data and hyperparameters as baseline
- Extended warmup for softplus stability
- Outputs: `monotonic_model.pt`, `monotonic_training_history.json`

#### Stage 4: Evaluate
Evaluates both models on benchmarks.
```bash
python scripts/stage_4_evaluate.py
```
- Computes perplexity on Pile test set
- Evaluates on LAMBADA, HellaSwag, Winogrande, TruthfulQA
- Uses lm-evaluation-harness for standardized benchmarks
- Outputs: `evaluation_results.json`

#### Stage 5: UAT Attacks
Tests Universal Adversarial Trigger attacks.
```bash
python scripts/stage_5_uat_attacks.py
```
- Optimizes adversarial triggers to maximize loss
- Tests attack transferability between models
- Measures robustness via perplexity degradation
- Outputs: `uat_results.json`

#### Stage 6: HotFlip Attacks
Tests HotFlip gradient-based attacks.
```bash
python scripts/stage_6_hotflip_attacks.py
```
- Applies gradient-based token flipping
- Measures impact on model predictions
- Compares baseline vs. monotonic robustness
- Outputs: `hotflip_results.json`

#### Stage 7: Aggregate Results
Combines all results into summary.
```bash
python scripts/stage_7_aggregate.py
```
- Aggregates metrics from all stages
- Computes statistical comparisons
- Generates human-readable summary
- Outputs: `final_results.json`, `experiment_summary.txt`

## Expected Outputs

After running all stages, you'll find in `$RESULTS_DIR`:

- `setup_complete.json`: Environment information
- `monotonicity_application_log.json`: Details of constraint application
- `baseline_training_history.json`: Baseline training metrics
- `monotonic_training_history.json`: Monotonic model training metrics
- `evaluation_results.json`: Benchmark evaluation results
- `uat_results.json`: UAT attack results
- `hotflip_results.json`: HotFlip attack results
- `final_results.json`: Aggregated results
- `experiment_summary.txt`: Human-readable summary

## Reproducing Results

To reproduce results with multiple random seeds:

```bash
for seed in 42 1337 2024 8888 12345; do
  export EXPERIMENT_SEED=$seed
  export WORK_DIR="./work_seed_${seed}"
  export RESULTS_DIR="./results_seed_${seed}"
  
  # Run all stages
  python scripts/stage_0_setup.py
  python scripts/stage_1_apply_monotonicity.py
  python scripts/stage_2_train_baseline.py
  python scripts/stage_3_train_monotonic.py
  python scripts/stage_4_evaluate.py
  python scripts/stage_5_uat_attacks.py
  python scripts/stage_6_hotflip_attacks.py
  python scripts/stage_7_aggregate.py
done
```

## Key Implementation Details

### Monotonic Constraint Implementation

The core monotonicity implementation is in `utils/common_utils.py`:

```python
class NonNegativeParametrization(nn.Module):
    """Softplus parametrization: W = softplus(V) >= 0"""
    def forward(self, V):
        return F.softplus(V)
    
    def right_inverse(self, W):
        """Initialize V from pretrained W"""
        eps = 1e-4
        W_abs = torch.abs(W) + eps
        V = torch.log(torch.exp(W_abs) - 1.0 + eps)
        return V
```

This parametrization is applied only to FFN linear layers using PyTorch's parametrization API:

```python
P.register_parametrization(
    module, "weight",
    NonNegativeParametrization(init_weight=current_weight)
)
```

### Fair Comparison Methodology

To ensure fair comparison between baseline and monotonic models:

1. **Same Starting Point**: Both start from same pretrained checkpoint
2. **Identical Training Data**: Same datasets, splits, and preprocessing
3. **Identical Hyperparameters**: 
   - Learning rate: 1e-5
   - Batch size: 8 (effective 32 with gradient accumulation)
   - Weight decay: 0.01
   - Gradient clipping: 1.0
4. **Only Difference**: Monotonic model has 15% warmup vs. 10% for baseline (for softplus stability)

### Evaluation Metrics

- **Primary Metric**: Perplexity on Pile test set
- **Generalization**: LAMBADA accuracy, HellaSwag/Winogrande/TruthfulQA scores
- **Robustness**: Perplexity degradation under UAT and HotFlip attacks
- **Statistical Significance**: Bootstrap confidence intervals where applicable

## Computational Requirements

### Runtime Estimates (on single A100 GPU)

- Stage 0 (Setup): ~30 minutes
- Stage 1 (Apply Monotonicity): ~15 minutes
- Stage 2 (Train Baseline): ~24 hours
- Stage 3 (Train Monotonic): ~32 hours
- Stage 4 (Evaluate): ~6 hours
- Stage 5 (UAT Attacks): ~4 hours
- Stage 6 (HotFlip): ~2 hours
- Stage 7 (Aggregate): ~5 minutes

**Total per seed: ~68 hours (~3 days)**

For 5 seeds: ~340 hours (~14 days on single GPU)

### Quick Testing Mode

For testing the pipeline without full training:

1. Edit `configs/experiment_config.py`:
   - Set `USE_FULL_EVAL_SETS = False`
   - Set `TRAINING_SAMPLES = QUICK_TRAINING_SAMPLES`
   - Set `RECOVERY_EPOCHS = 0.1` (partial epoch)

2. Run pipeline as normal

This reduces runtime from ~68 hours to ~2 hours per seed.

## Troubleshooting

### Out of Memory (OOM)

If you encounter CUDA out of memory errors:

1. Reduce `BATCH_SIZE` in `configs/experiment_config.py` (try 4 or 2)
2. Increase `GRADIENT_ACCUMULATION_STEPS` to maintain effective batch size
3. Use a smaller model: `MODEL_NAME = "EleutherAI/pythia-410m"`
4. Enable gradient checkpointing (add to training scripts)

### Slow Training

- Ensure CUDA is properly installed: `python -c "import torch; print(torch.cuda.is_available())"`
- Monitor GPU utilization: `nvidia-smi -l 1`
- Verify you're not using CPU-only PyTorch
- Consider distributed training across multiple GPUs

### Dataset Download Failures

- Ensure internet connectivity
- Set `HF_DATASETS_CACHE` environment variable to a directory with sufficient space
- Pre-download datasets manually: `python -c "from datasets import load_dataset; load_dataset('EleutherAI/pile')"`

### Dependency Errors

If stages fail due to missing dependencies:

```bash
# Check which stage completed
ls $WORK_DIR/*.flag

# Re-run the failed stage
python scripts/stage_X_name.py
```

Each stage checks for required completion flags from previous stages.

## Citation

If you use this code, please cite our paper:

```
[Citation information to be added after de-anonymization]
```

## License

[License information to be added after de-anonymization]

## Contact

For questions about the code, please refer to the paper for methodology details. For technical issues, check the troubleshooting section above.

## Acknowledgments

This implementation builds upon:
- Hugging Face Transformers library
- EleutherAI's Pythia models and lm-evaluation-harness
- PyTorch parametrization API

The experimental methodology follows best practices from:
- Dodge et al. (2019): "Show Your Work: Improved Reporting of Experimental Results"
- Belz et al. (2021): "A Systematic Review of Reproducibility Research in NLP"
