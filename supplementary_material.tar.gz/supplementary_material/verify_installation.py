#!/usr/bin/env python3
"""
Verify Installation Script

Run this script to verify that all dependencies are installed correctly
and the code is properly configured.
"""

import sys
import os

def check_python_version():
    """Check Python version"""
    print("Checking Python version...")
    version = sys.version_info
    if version.major < 3 or (version.major == 3 and version.minor < 10):
        print(f"  ERROR: Python 3.10+ required, found {version.major}.{version.minor}.{version.micro}")
        return False
    print(f"  OK: Python {version.major}.{version.minor}.{version.micro}")
    return True

def check_dependencies():
    """Check if all required dependencies are installed"""
    print("\nChecking dependencies...")
    
    required_packages = [
        ('torch', 'PyTorch'),
        ('transformers', 'Transformers'),
        ('datasets', 'Datasets'),
        ('numpy', 'NumPy'),
        ('scipy', 'SciPy'),
        ('sklearn', 'scikit-learn'),
        ('tqdm', 'tqdm'),
        ('pandas', 'pandas'),
    ]
    
    all_ok = True
    for module_name, display_name in required_packages:
        try:
            __import__(module_name)
            print(f"  OK: {display_name}")
        except ImportError:
            print(f"  ERROR: {display_name} not installed")
            all_ok = False
    
    return all_ok

def check_cuda():
    """Check CUDA availability"""
    print("\nChecking CUDA availability...")
    try:
        import torch
        if torch.cuda.is_available():
            print(f"  OK: CUDA available")
            print(f"      Device: {torch.cuda.get_device_name(0)}")
            print(f"      Memory: {torch.cuda.get_device_properties(0).total_memory / 1e9:.1f} GB")
            return True
        else:
            print("  WARNING: CUDA not available - training will be very slow!")
            print("           For production runs, GPU is strongly recommended.")
            return True
    except Exception as e:
        print(f"  ERROR: Could not check CUDA: {e}")
        return False

def check_imports():
    """Check if custom modules can be imported"""
    print("\nChecking custom modules...")
    
    # Add parent directory to path
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    
    all_ok = True
    
    # Try importing config
    try:
        from configs.experiment_config import ExperimentConfig
        print("  OK: configs.experiment_config")
    except Exception as e:
        print(f"  ERROR: Could not import configs.experiment_config: {e}")
        all_ok = False
    
    # Try importing utils
    try:
        from utils.common_utils import set_all_seeds, make_model_monotonic
        print("  OK: utils.common_utils")
    except Exception as e:
        print(f"  ERROR: Could not import utils.common_utils: {e}")
        all_ok = False
    
    return all_ok

def check_directories():
    """Check if required directories exist"""
    print("\nChecking project structure...")
    
    required_dirs = [
        'configs',
        'scripts',
        'utils',
    ]
    
    all_ok = True
    for dir_name in required_dirs:
        if os.path.isdir(dir_name):
            print(f"  OK: {dir_name}/")
        else:
            print(f"  ERROR: {dir_name}/ not found")
            all_ok = False
    
    # Check for required files
    required_files = [
        'README.md',
        'requirements.txt',
        'configs/experiment_config.py',
        'utils/common_utils.py',
    ]
    
    for file_name in required_files:
        if os.path.isfile(file_name):
            print(f"  OK: {file_name}")
        else:
            print(f"  ERROR: {file_name} not found")
            all_ok = False
    
    # Count scripts
    script_files = [f for f in os.listdir('scripts') if f.startswith('stage_') and f.endswith('.py')]
    if len(script_files) == 8:
        print(f"  OK: Found all 8 stage scripts")
    else:
        print(f"  WARNING: Expected 8 stage scripts, found {len(script_files)}")
    
    return all_ok

def main():
    """Run all verification checks"""
    print("="*80)
    print("SUPPLEMENTARY MATERIAL VERIFICATION")
    print("="*80)
    
    checks = [
        ("Python Version", check_python_version),
        ("Dependencies", check_dependencies),
        ("CUDA", check_cuda),
        ("Custom Modules", check_imports),
        ("Project Structure", check_directories),
    ]
    
    results = []
    for name, check_func in checks:
        try:
            result = check_func()
            results.append((name, result))
        except Exception as e:
            print(f"\nERROR in {name}: {e}")
            results.append((name, False))
    
    # Summary
    print("\n" + "="*80)
    print("VERIFICATION SUMMARY")
    print("="*80)
    
    all_passed = True
    for name, result in results:
        status = "PASS" if result else "FAIL"
        symbol = "✓" if result else "✗"
        print(f"{symbol} {name}: {status}")
        if not result:
            all_passed = False
    
    print("="*80)
    
    if all_passed:
        print("\nSUCCESS: All verification checks passed!")
        print("You can now run the experiments using the stage scripts.")
        print("\nQuick start:")
        print("  python scripts/stage_0_setup.py")
        return 0
    else:
        print("\nFAILURE: Some verification checks failed.")
        print("Please install missing dependencies or fix errors before proceeding.")
        print("\nTo install dependencies:")
        print("  pip install -r requirements.txt")
        return 1

if __name__ == "__main__":
    sys.exit(main())
