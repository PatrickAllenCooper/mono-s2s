"""Configuration for monotonicity experiments"""

from .experiment_config import ExperimentConfig

__all__ = ['ExperimentConfig']
