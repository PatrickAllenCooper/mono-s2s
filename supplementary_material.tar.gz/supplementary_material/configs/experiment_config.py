"""
Configuration for Monotonicity Experiments

This configuration supports experiments testing whether monotonic constraints
on neural network weights improve adversarial robustness.
"""

import os
import torch

class ExperimentConfig:
    """Configuration for monotonicity experiments"""
    
    # ======================================================================
    # PATHS (CUSTOMIZE FOR YOUR ENVIRONMENT)
    # ======================================================================
    
    WORK_DIR = os.environ.get("WORK_DIR", "./work")
    RESULTS_DIR = os.environ.get("RESULTS_DIR", "./results")
    CHECKPOINT_DIR = os.path.join(WORK_DIR, "checkpoints")
    DATA_CACHE_DIR = os.path.join(WORK_DIR, "data_cache")
    
    # ======================================================================
    # MODEL CONFIGURATION
    # ======================================================================
    
    # Foundation model selection
    MODEL_NAME = "EleutherAI/pythia-1.4b"
    MODEL_REVISION = "main"
    
    # Model architecture info
    HIDDEN_SIZE = 2048
    NUM_LAYERS = 24
    NUM_ATTENTION_HEADS = 16
    FFN_INTERMEDIATE_SIZE = 8192  # 4x hidden size
    
    # ======================================================================
    # RANDOM SEEDS
    # ======================================================================
    
    RANDOM_SEEDS = [42, 1337, 2024, 8888, 12345]
    CURRENT_SEED = int(os.environ.get("EXPERIMENT_SEED", "42"))
    
    # ======================================================================
    # TRAINING HYPERPARAMETERS
    # ======================================================================
    
    # Recovery training (restore performance after monotonicity initialization)
    RECOVERY_EPOCHS = 1
    RECOVERY_LR = 1e-5
    RECOVERY_WARMUP_RATIO = 0.10
    RECOVERY_WEIGHT_DECAY = 0.01
    
    # Monotonic recovery (same data, extended warmup for stability)
    MONOTONIC_RECOVERY_EPOCHS = 1
    MONOTONIC_RECOVERY_LR = 1e-5
    MONOTONIC_RECOVERY_WARMUP_RATIO = 0.15  # More warmup for softplus stability
    MONOTONIC_RECOVERY_WEIGHT_DECAY = 0.01
    
    # Training batch sizes
    BATCH_SIZE = 8  # Per-device batch size
    GRADIENT_ACCUMULATION_STEPS = 4  # Effective batch size = 32
    MAX_GRAD_NORM = 1.0
    
    # Sequence length
    MAX_SEQ_LENGTH = 2048
    
    # ======================================================================
    # EVALUATION CONFIGURATION
    # ======================================================================
    
    # Evaluation batch size (can be larger than training)
    EVAL_BATCH_SIZE = 16
    
    # Evaluation benchmarks
    EVAL_BENCHMARKS = [
        "pile_test",      # Perplexity on Pile test set (primary metric)
        "lambada",        # Language modeling (next-word prediction)
        "hellaswag",      # Commonsense reasoning
        "winogrande",     # Coreference resolution
        "truthfulqa",     # Factuality
    ]
    
    # Evaluation dataset sizes
    USE_FULL_EVAL_SETS = True  # Set to False for quick testing
    
    # Quick testing sizes (when USE_FULL_EVAL_SETS=False)
    QUICK_EVAL_SIZE = 500
    QUICK_PILE_TEST_SIZE = 1000
    
    # Full evaluation sizes
    FULL_PILE_TEST_SIZE = 10000  # 10K examples from Pile test
    
    # ======================================================================
    # TRAINING DATA CONFIGURATION
    # ======================================================================
    
    # Training dataset (for recovery phase)
    TRAINING_DATASET = "EleutherAI/pile"
    TRAINING_SUBSET = "all"
    TRAINING_SAMPLES = None  # None = full dataset, set number for quick tests
    
    # For quick testing
    QUICK_TRAINING_SAMPLES = 10000
    
    # ======================================================================
    # ATTACK CONFIGURATION
    # ======================================================================
    
    # Universal Adversarial Triggers
    ATTACK_TRIGGER_LENGTH = 10
    ATTACK_NUM_CANDIDATES = 200
    ATTACK_NUM_RESTARTS = 5
    ATTACK_NUM_ITERATIONS = 100
    
    # HotFlip attacks
    HOTFLIP_NUM_FLIPS = 10
    HOTFLIP_NUM_SAMPLES = 200
    
    # Attack evaluation
    ATTACK_LOSS_BATCH_SIZE = 8
    ATTACK_SUCCESS_THRESHOLD = 0.15  # 15% perplexity increase
    
    # ======================================================================
    # LOGGING & CHECKPOINTING
    # ======================================================================
    
    SAVE_CHECKPOINT_EVERY_N_STEPS = 5000
    LOG_EVERY_N_STEPS = 100
    VERBOSE_LOGGING = True
    
    # ======================================================================
    # HELPER METHODS
    # ======================================================================
    
    @classmethod
    def to_dict(cls):
        """Export configuration as dictionary"""
        return {
            k: v for k, v in cls.__dict__.items() 
            if not k.startswith('_') and not callable(v) and k.isupper()
        }
    
    @classmethod
    def create_directories(cls):
        """Create all necessary directories"""
        dirs = [
            cls.WORK_DIR,
            cls.RESULTS_DIR,
            cls.CHECKPOINT_DIR,
            cls.DATA_CACHE_DIR,
            os.path.join(cls.CHECKPOINT_DIR, 'baseline_checkpoints'),
            os.path.join(cls.CHECKPOINT_DIR, 'monotonic_checkpoints'),
        ]
        for d in dirs:
            os.makedirs(d, exist_ok=True)
        print(f"Created all directories under {cls.WORK_DIR}")
    
    @classmethod
    def get_device(cls):
        """Get compute device"""
        if torch.cuda.is_available():
            device = torch.device("cuda")
            print(f"Using GPU: {torch.cuda.get_device_name(0)}")
            print(f"Memory: {torch.cuda.get_device_properties(0).total_memory / 1e9:.1f} GB")
        else:
            device = torch.device("cpu")
            print("Using CPU (no GPU available)")
        return device
    
    @classmethod
    def validate_config(cls):
        """Validate configuration"""
        issues = []
        
        if not torch.cuda.is_available():
            issues.append("No GPU available - training will be very slow!")
        
        if issues:
            print("\nConfiguration Issues:")
            for issue in issues:
                print(f"  - {issue}")
            return False
        else:
            print("Configuration validated successfully")
            return True


if __name__ == "__main__":
    print("="*80)
    print("MONOTONICITY EXPERIMENT CONFIGURATION")
    print("="*80)
    
    config = ExperimentConfig
    print(f"\nModel: {config.MODEL_NAME}")
    print(f"Seed: {config.CURRENT_SEED}")
    print(f"Work dir: {config.WORK_DIR}")
    
    print("\nValidating...")
    config.validate_config()
    
    print("\nConfiguration ready for experiments")
